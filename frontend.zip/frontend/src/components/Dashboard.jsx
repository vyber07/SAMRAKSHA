import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore, useDashboardStore } from '../lib/store';
import { analytics, incidents, cases, hotspot } from '../lib/api';
import Sidebar from './Sidebar';
import TopBar from './TopBar';
import IncidentTile from './widgets/IncidentTile';
import CaseCard from './widgets/CaseCard';
import NotificationTile from './widgets/NotificationTile';
import MapWidget from './widgets/MapWidget';
import StatsCard from './widgets/StatsCard';

export default function Dashboard() {
  const navigate = useNavigate();
  const token = useAuthStore((state) => state.token);
  const { incidents: incidentList, cases: caseList } = useDashboardStore();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token) {
      navigate('/login');
      return;
    }
    loadDashboardData();
  }, [token, navigate]);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const [analyticsRes, incidentsRes, casesRes] = await Promise.all([
        analytics.dashboard(),
        incidents.list(0, 10),
        cases.list(0, 10),
      ]);

      setStats(analyticsRes.data);
      useDashboardStore.setState({
        incidents: incidentsRes.data.items || [],
        cases: casesRes.data.items || [],
      });
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      display: 'flex',
      height: '100vh',
      background: 'var(--dark-bg)',
      color: 'var(--light-text)',
    }}>
      <Sidebar />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <TopBar onRefresh={loadDashboardData} />
        <div style={{
          flex: 1,
          overflow: 'auto',
          padding: '24px',
          background: 'linear-gradient(135deg, #0f172a 0%, #1a2332 100%)',
        }}>
          {/* Quick Stats */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '16px',
            marginBottom: '24px',
          }}>
            {stats && [
              { label: 'Total Cases', value: stats.total_cases, color: '#6366f1' },
              { label: 'Active Incidents', value: stats.active_incidents, color: '#ec4899' },
              { label: 'Solved Cases', value: stats.solved_cases, color: '#10b981' },
              { label: 'Crime Hotspots', value: stats.hotspots, color: '#f59e0b' },
            ].map((stat, i) => (
              <StatsCard key={i} {...stat} />
            ))}
          </div>

          {/* Main content grid */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '20px',
            marginBottom: '24px',
          }}>
            {/* Left column */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {/* Map Widget */}
              <MapWidget />

              {/* Quick Notifications */}
              <div>
                <h2 style={{ marginBottom: '12px', fontSize: '18px', fontWeight: '600' }}>
                  Quick Notifications
                </h2>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {[
                    { title: 'New Incident', desc: 'Case #2024-001 updated', severity: 'high' },
                    { title: 'Alert', desc: 'Suspicious activity detected', severity: 'medium' },
                    { title: 'Info', desc: 'Patrol unit 5 check-in OK', severity: 'low' },
                  ].map((notif, i) => (
                    <NotificationTile key={i} {...notif} />
                  ))}
                </div>
              </div>
            </div>

            {/* Right column */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {/* Recent Incidents */}
              <div>
                <h2 style={{ marginBottom: '12px', fontSize: '18px', fontWeight: '600' }}>
                  Recent Incidents
                </h2>
                <div style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                  maxHeight: '400px',
                  overflow: 'auto',
                }}>
                  {incidentList.slice(0, 4).map((incident) => (
                    <IncidentTile key={incident.id} incident={incident} />
                  ))}
                </div>
              </div>

              {/* Quick Access Cases */}
              <div>
                <h2 style={{ marginBottom: '12px', fontSize: '18px', fontWeight: '600' }}>
                  Priority Cases
                </h2>
                <div style={{
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '8px',
                  maxHeight: '300px',
                  overflow: 'auto',
                }}>
                  {caseList.slice(0, 3).map((c) => (
                    <CaseCard key={c.id} case={c} />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
