import React, { useEffect, useState } from 'react';
import { cctv as cctvApi } from '../lib/api';
import Sidebar from '../components/Sidebar';
import TopBar from '../components/TopBar';

export default function CCTVPage() {
  const [cameras, setCameras] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCameras();
  }, []);

  const loadCameras = async () => {
    try {
      setLoading(true);
      const res = await cctvApi.list();
      setCameras(res.data);
    } catch (error) {
      console.error('Failed to load CCTV data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    return status === 'online' ? '#10b981' : '#ef4444';
  };

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <Sidebar />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <TopBar onRefresh={loadCameras} />
        <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
          <h1 style={{ marginBottom: '24px', color: '#f1f5f9' }}>CCTV Monitoring</h1>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
            gap: '20px',
          }}>
            {loading ? (
              <div style={{ color: '#cbd5e1' }}>Loading camera feed...</div>
            ) : cameras.length === 0 ? (
              <div style={{
                gridColumn: '1 / -1',
                padding: '40px',
                textAlign: 'center',
                background: 'rgba(30, 41, 59, 0.7)',
                borderRadius: '12px',
                color: '#cbd5e1',
                border: '1px solid rgba(148, 163, 184, 0.2)',
              }}>
                No cameras found
              </div>
            ) : (
              cameras.map((camera, i) => {
                const statusColor = getStatusColor(camera.status);
                return (
                  <div
                    key={i}
                    style={{
                      background: 'rgba(30, 41, 59, 0.7)',
                      backdropFilter: 'blur(10px)',
                      border: `1px solid ${statusColor}30`,
                      borderRadius: '16px',
                      overflow: 'hidden',
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = 'scale(1.02)';
                      e.currentTarget.style.boxShadow = `0 8px 24px ${statusColor}30`;
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = 'scale(1)';
                      e.currentTarget.style.boxShadow = 'none';
                    }}
                  >
                    {/* Camera feed placeholder */}
                    <div style={{
                      width: '100%',
                      height: '200px',
                      background: `linear-gradient(135deg, rgba(99, 102, 241, 0.1), rgba(236, 72, 153, 0.1))`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '14px',
                      color: '#cbd5e1',
                      borderBottom: `1px solid ${statusColor}30`,
                    }}>
                      📹 Camera Feed
                    </div>

                    {/* Camera info */}
                    <div style={{ padding: '16px' }}>
                      <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        marginBottom: '12px',
                      }}>
                        <h3 style={{ margin: 0, color: '#f1f5f9', fontSize: '16px' }}>
                          Camera {camera.camera_id || i + 1}
                        </h3>
                        <div style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                          padding: '4px 10px',
                          borderRadius: '6px',
                          background: `${statusColor}20`,
                          color: statusColor,
                          fontSize: '11px',
                          fontWeight: '600',
                        }}>
                          <div style={{
                            width: '6px',
                            height: '6px',
                            borderRadius: '50%',
                            background: statusColor,
                          }} />
                          {camera.status?.toUpperCase() || 'ONLINE'}
                        </div>
                      </div>

                      <div style={{ fontSize: '12px', color: '#cbd5e1', lineHeight: '1.6' }}>
                        <div style={{ marginBottom: '8px' }}>
                          📍 <strong>Location:</strong> {camera.location || 'Central Area'}
                        </div>
                        <div style={{ marginBottom: '8px' }}>
                          🎥 <strong>Type:</strong> {camera.camera_type || 'Fixed'}
                        </div>
                        <div>
                          ⏱️ <strong>Last Sync:</strong> {camera.last_sync ? new Date(camera.last_sync).toLocaleTimeString() : 'Just now'}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
