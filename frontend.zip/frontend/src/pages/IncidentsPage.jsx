import React, { useEffect, useState } from 'react';
import { incidents } from '../lib/api';
import Sidebar from '../components/Sidebar';
import TopBar from '../components/TopBar';

export default function IncidentsPage() {
  const [incidentsList, setIncidentsList] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadIncidents();
  }, []);

  const loadIncidents = async () => {
    try {
      setLoading(true);
      const res = await incidents.list(0, 50);
      setIncidentsList(res.data.items || []);
    } catch (error) {
      console.error('Failed to load incidents:', error);
    } finally {
      setLoading(false);
    }
  };

  const getSeverityColor = (severity) => {
    const colors = {
      critical: '#ef4444',
      high: '#f59e0b',
      medium: '#ec4899',
      low: '#10b981',
    };
    return colors[severity] || '#6366f1';
  };

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <Sidebar />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <TopBar onRefresh={loadIncidents} />
        <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
          <h1 style={{ marginBottom: '24px', color: '#f1f5f9' }}>Active Incidents</h1>

          {loading ? (
            <div style={{ color: '#cbd5e1' }}>Loading incidents...</div>
          ) : (
            <div style={{ display: 'grid', gap: '16px' }}>
              {incidentsList.length === 0 ? (
                <div style={{
                  padding: '40px',
                  textAlign: 'center',
                  background: 'rgba(30, 41, 59, 0.7)',
                  borderRadius: '12px',
                  color: '#cbd5e1',
                  border: '1px solid rgba(148, 163, 184, 0.2)',
                }}>
                  No incidents found
                </div>
              ) : (
                incidentsList.map((incident) => {
                  const sevColor = getSeverityColor(incident.severity);
                  return (
                    <div
                      key={incident.id}
                      style={{
                        background: 'rgba(30, 41, 59, 0.7)',
                        backdropFilter: 'blur(10px)',
                        border: `1px solid ${sevColor}30`,
                        borderRadius: '12px',
                        padding: '20px',
                        cursor: 'pointer',
                        transition: 'all 0.2s',
                        display: 'flex',
                        gap: '16px',
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.background = 'rgba(30, 41, 59, 0.9)';
                        e.currentTarget.style.boxShadow = `0 8px 24px ${sevColor}30`;
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.background = 'rgba(30, 41, 59, 0.7)';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                    >
                      <div style={{
                        width: '4px',
                        borderRadius: '2px',
                        background: sevColor,
                        flexShrink: 0,
                      }} />
                      <div style={{ flex: 1 }}>
                        <h3 style={{ margin: '0 0 8px 0', color: '#f1f5f9' }}>
                          {incident.title || `Incident #${incident.id}`}
                        </h3>
                        <p style={{ color: '#cbd5e1', margin: '0 0 12px 0' }}>
                          {incident.description || 'No description'}
                        </p>
                        <div style={{ display: 'flex', gap: '16px', fontSize: '12px', color: '#94a3b8' }}>
                          <span>📍 {incident.location || 'Unknown location'}</span>
                          <span>🕐 {new Date(incident.created_at).toLocaleTimeString()}</span>
                        </div>
                      </div>
                      <div style={{
                        padding: '8px 16px',
                        borderRadius: '8px',
                        background: `${sevColor}20`,
                        color: sevColor,
                        fontSize: '12px',
                        fontWeight: '600',
                        height: 'fit-content',
                      }}>
                        {incident.severity?.toUpperCase() || 'MEDIUM'}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
