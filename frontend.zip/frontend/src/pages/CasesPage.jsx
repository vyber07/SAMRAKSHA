import React, { useEffect, useState } from 'react';
import { cases } from '../lib/api';
import Sidebar from '../components/Sidebar';
import TopBar from '../components/TopBar';

export default function CasesPage() {
  const [casesList, setCasesList] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCases();
  }, []);

  const loadCases = async () => {
    try {
      setLoading(true);
      const res = await cases.list(0, 50);
      setCasesList(res.data.items || []);
    } catch (error) {
      console.error('Failed to load cases:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <Sidebar />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <TopBar onRefresh={loadCases} />
        <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
          <h1 style={{ marginBottom: '24px', color: '#f1f5f9' }}>Cases Management</h1>

          {loading ? (
            <div style={{ color: '#cbd5e1' }}>Loading cases...</div>
          ) : (
            <div style={{ display: 'grid', gap: '16px' }}>
              {casesList.length === 0 ? (
                <div style={{
                  padding: '40px',
                  textAlign: 'center',
                  background: 'rgba(30, 41, 59, 0.7)',
                  borderRadius: '12px',
                  color: '#cbd5e1',
                  border: '1px solid rgba(148, 163, 184, 0.2)',
                }}>
                  No cases found
                </div>
              ) : (
                casesList.map((c) => (
                  <div
                    key={c.id}
                    style={{
                      background: 'rgba(30, 41, 59, 0.7)',
                      backdropFilter: 'blur(10px)',
                      border: '1px solid rgba(148, 163, 184, 0.2)',
                      borderRadius: '12px',
                      padding: '20px',
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'rgba(30, 41, 59, 0.9)';
                      e.currentTarget.style.transform = 'translateX(4px)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'rgba(30, 41, 59, 0.7)';
                      e.currentTarget.style.transform = 'translateX(0)';
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px' }}>
                      <h3 style={{ margin: 0, color: '#f1f5f9' }}>{c.case_title || `Case #${c.id}`}</h3>
                      <span style={{
                        padding: '6px 12px',
                        borderRadius: '6px',
                        background: 'rgba(99, 102, 241, 0.2)',
                        color: '#6366f1',
                        fontSize: '12px',
                        fontWeight: '600',
                      }}>
                        {c.status?.toUpperCase() || 'OPEN'}
                      </span>
                    </div>
                    <p style={{ color: '#cbd5e1', margin: '0 0 12px 0' }}>
                      {c.description || 'No description'}
                    </p>
                    <div style={{ display: 'flex', gap: '16px', fontSize: '12px', color: '#94a3b8' }}>
                      <span>📁 FIR: {c.fir_number}</span>
                      <span>📍 {c.location || 'Unknown'}</span>
                      <span>📅 {new Date(c.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
