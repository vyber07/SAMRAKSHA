import React, { useEffect, useState } from 'react';
import { analytics } from '../lib/api';
import Sidebar from '../components/Sidebar';
import TopBar from '../components/TopBar';

export default function AnalyticsPage() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      const res = await analytics.dashboard();
      setStats(res.data);
    } catch (error) {
      console.error('Failed to load analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', height: '100vh' }}>
        <Sidebar />
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ color: '#cbd5e1' }}>Loading analytics...</div>
        </div>
      </div>
    );
  }

  const statsCards = [
    { label: 'Total Cases', value: stats?.total_cases, color: '#6366f1' },
    { label: 'Active Incidents', value: stats?.active_incidents, color: '#ec4899' },
    { label: 'Solved Cases', value: stats?.solved_cases, color: '#10b981' },
    { label: 'Pending Review', value: stats?.pending_review || 0, color: '#f59e0b' },
  ];

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <Sidebar />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <TopBar onRefresh={loadAnalytics} />
        <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
          <h1 style={{ marginBottom: '32px', color: '#f1f5f9' }}>Analytics & Insights</h1>

          {/* Key metrics */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '20px',
            marginBottom: '32px',
          }}>
            {statsCards.map((card, i) => (
              <div
                key={i}
                style={{
                  background: 'rgba(30, 41, 59, 0.7)',
                  backdropFilter: 'blur(10px)',
                  border: `1px solid ${card.color}20`,
                  borderRadius: '16px',
                  padding: '24px',
                  cursor: 'pointer',
                  transition: 'all 0.3s',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-4px)';
                  e.currentTarget.style.boxShadow = `0 8px 24px ${card.color}30`;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              >
                <div style={{
                  fontSize: '12px',
                  color: '#cbd5e1',
                  fontWeight: '500',
                  marginBottom: '12px',
                }}>
                  {card.label}
                </div>
                <div style={{
                  fontSize: '48px',
                  fontWeight: '700',
                  color: card.color,
                  marginBottom: '16px',
                }}>
                  {card.value || 0}
                </div>
                <div style={{
                  height: '4px',
                  borderRadius: '2px',
                  background: `${card.color}20`,
                  overflow: 'hidden',
                }}>
                  <div style={{
                    height: '100%',
                    background: card.color,
                    width: '65%',
                    borderRadius: '2px',
                  }} />
                </div>
              </div>
            ))}
          </div>

          {/* Summary section */}
          <div style={{
            background: 'rgba(30, 41, 59, 0.7)',
            backdropFilter: 'blur(10px)',
            border: '1px solid rgba(148, 163, 184, 0.2)',
            borderRadius: '16px',
            padding: '24px',
          }}>
            <h2 style={{ marginBottom: '24px', color: '#f1f5f9' }}>Summary</h2>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
              gap: '16px',
            }}>
              <div style={{
                padding: '16px',
                background: 'rgba(99, 102, 241, 0.1)',
                borderRadius: '12px',
                borderLeft: '4px solid #6366f1',
              }}>
                <div style={{ color: '#cbd5e1', fontSize: '12px', marginBottom: '8px' }}>
                  Closure Rate
                </div>
                <div style={{ color: '#6366f1', fontSize: '24px', fontWeight: '700' }}>
                  {stats?.solved_cases && stats?.total_cases
                    ? Math.round((stats.solved_cases / stats.total_cases) * 100)
                    : 0}%
                </div>
              </div>
              <div style={{
                padding: '16px',
                background: 'rgba(236, 72, 153, 0.1)',
                borderRadius: '12px',
                borderLeft: '4px solid #ec4899',
              }}>
                <div style={{ color: '#cbd5e1', fontSize: '12px', marginBottom: '8px' }}>
                  Incident Response
                </div>
                <div style={{ color: '#ec4899', fontSize: '24px', fontWeight: '700' }}>
                  ~15 min
                </div>
              </div>
              <div style={{
                padding: '16px',
                background: 'rgba(16, 185, 129, 0.1)',
                borderRadius: '12px',
                borderLeft: '4px solid #10b981',
              }}>
                <div style={{ color: '#cbd5e1', fontSize: '12px', marginBottom: '8px' }}>
                  Active Stations
                </div>
                <div style={{ color: '#10b981', fontSize: '24px', fontWeight: '700' }}>
                  12
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
