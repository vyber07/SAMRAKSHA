import React, { useState } from 'react';
import Sidebar from '../components/Sidebar';
import TopBar from '../components/TopBar';

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState('users');

  const tabs = [
    { id: 'users', label: '👥 Users', icon: '👥' },
    { id: 'roles', label: '🔐 Roles', icon: '🔐' },
    { id: 'settings', label: '⚙️ Settings', icon: '⚙️' },
    { id: 'logs', label: '📋 Logs', icon: '📋' },
  ];

  const handleRefresh = () => {
    console.log('Refreshing admin data...');
  };

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <Sidebar />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <TopBar onRefresh={handleRefresh} />
        <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
          <h1 style={{ marginBottom: '24px', color: '#f1f5f9' }}>Administration</h1>

          {/* Tabs */}
          <div style={{
            display: 'flex',
            gap: '12px',
            marginBottom: '24px',
            borderBottom: '1px solid rgba(148, 163, 184, 0.1)',
            paddingBottom: '12px',
          }}>
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                style={{
                  padding: '10px 16px',
                  borderRadius: '8px',
                  border: 'none',
                  background: activeTab === tab.id ? 'rgba(99, 102, 241, 0.2)' : 'transparent',
                  color: activeTab === tab.id ? '#6366f1' : '#cbd5e1',
                  fontSize: '14px',
                  fontWeight: activeTab === tab.id ? '600' : '500',
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                  borderBottom: activeTab === tab.id ? '2px solid #6366f1' : '2px solid transparent',
                }}
                onMouseEnter={(e) => {
                  if (activeTab !== tab.id) {
                    e.target.style.color = '#f1f5f9';
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeTab !== tab.id) {
                    e.target.style.color = '#cbd5e1';
                  }
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab content */}
          <div style={{
            background: 'rgba(30, 41, 59, 0.7)',
            backdropFilter: 'blur(10px)',
            border: '1px solid rgba(148, 163, 184, 0.2)',
            borderRadius: '16px',
            padding: '24px',
            minHeight: '400px',
          }}>
            {activeTab === 'users' && (
              <div>
                <h2 style={{ marginBottom: '16px', color: '#f1f5f9', fontSize: '18px' }}>User Management</h2>
                <p style={{ color: '#cbd5e1', marginBottom: '16px' }}>Manage system users, roles, and permissions.</p>
                <div style={{
                  padding: '24px',
                  textAlign: 'center',
                  background: 'rgba(99, 102, 241, 0.1)',
                  borderRadius: '12px',
                  color: '#cbd5e1',
                  border: '1px solid rgba(99, 102, 241, 0.2)',
                }}>
                  User management interface coming soon
                </div>
              </div>
            )}

            {activeTab === 'roles' && (
              <div>
                <h2 style={{ marginBottom: '16px', color: '#f1f5f9', fontSize: '18px' }}>Role Management</h2>
                <p style={{ color: '#cbd5e1', marginBottom: '16px' }}>Configure roles and access control.</p>
                <div style={{
                  padding: '24px',
                  textAlign: 'center',
                  background: 'rgba(99, 102, 241, 0.1)',
                  borderRadius: '12px',
                  color: '#cbd5e1',
                  border: '1px solid rgba(99, 102, 241, 0.2)',
                }}>
                  Role management interface coming soon
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div>
                <h2 style={{ marginBottom: '16px', color: '#f1f5f9', fontSize: '18px' }}>System Settings</h2>
                <p style={{ color: '#cbd5e1', marginBottom: '16px' }}>Configure system-wide settings and preferences.</p>
                <div style={{
                  padding: '24px',
                  textAlign: 'center',
                  background: 'rgba(99, 102, 241, 0.1)',
                  borderRadius: '12px',
                  color: '#cbd5e1',
                  border: '1px solid rgba(99, 102, 241, 0.2)',
                }}>
                  Settings interface coming soon
                </div>
              </div>
            )}

            {activeTab === 'logs' && (
              <div>
                <h2 style={{ marginBottom: '16px', color: '#f1f5f9', fontSize: '18px' }}>System Logs</h2>
                <p style={{ color: '#cbd5e1', marginBottom: '16px' }}>View system activity and audit logs.</p>
                <div style={{
                  padding: '24px',
                  textAlign: 'center',
                  background: 'rgba(99, 102, 241, 0.1)',
                  borderRadius: '12px',
                  color: '#cbd5e1',
                  border: '1px solid rgba(99, 102, 241, 0.2)',
                }}>
                  Logs interface coming soon
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
