import React, { useEffect, useState } from 'react';
import { patrol } from '../lib/api';
import Sidebar from '../components/Sidebar';
import TopBar from '../components/TopBar';

export default function PatrolPage() {
  const [units, setUnits] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPatrols();
  }, []);

  const loadPatrols = async () => {
    try {
      setLoading(true);
      const res = await patrol.list();
      setUnits(res.data);
    } catch (error) {
      console.error('Failed to load patrol data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      active: '#10b981',
      idle: '#f59e0b',
      responding: '#ec4899',
      offline: '#ef4444',
    };
    return colors[status] || '#6366f1';
  };

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <Sidebar />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <TopBar onRefresh={loadPatrols} />
        <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
          <h1 style={{ marginBottom: '24px', color: '#f1f5f9' }}>Patrol Units</h1>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px' }}>
            {loading ? (
              <div style={{ color: '#cbd5e1' }}>Loading patrol units...</div>
            ) : units.length === 0 ? (
              <div style={{
                gridColumn: '1 / -1',
                padding: '40px',
                textAlign: 'center',
                background: 'rgba(30, 41, 59, 0.7)',
                borderRadius: '12px',
                color: '#cbd5e1',
                border: '1px solid rgba(148, 163, 184, 0.2)',
              }}>
                No patrol units available
              </div>
            ) : (
              units.map((unit, i) => {
                const statusColor = getStatusColor(unit.status);
                return (
                  <div
                    key={i}
                    style={{
                      background: 'rgba(30, 41, 59, 0.7)',
                      backdropFilter: 'blur(10px)',
                      border: `1px solid ${statusColor}30`,
                      borderRadius: '16px',
                      padding: '20px',
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'rgba(30, 41, 59, 0.9)';
                      e.currentTarget.style.transform = 'translateY(-2px)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'rgba(30, 41, 59, 0.7)';
                      e.currentTarget.style.transform = 'translateY(0)';
                    }}
                  >
                    <div style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      marginBottom: '16px',
                    }}>
                      <h3 style={{ margin: 0, color: '#f1f5f9', fontSize: '18px' }}>
                        Unit {unit.unit_number || i + 1}
                      </h3>
                      <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                      }}>
                        <div style={{
                          width: '10px',
                          height: '10px',
                          borderRadius: '50%',
                          background: statusColor,
                          animation: 'pulse 2s infinite',
                        }} />
                        <span style={{ color: statusColor, fontSize: '12px', fontWeight: '600' }}>
                          {unit.status?.toUpperCase() || 'ACTIVE'}
                        </span>
                      </div>
                    </div>

                    <div style={{
                      display: 'grid',
                      gridTemplateColumns: '1fr 1fr',
                      gap: '12px',
                      marginBottom: '16px',
                      fontSize: '13px',
                    }}>
                      <div style={{ color: '#cbd5e1' }}>
                        <div style={{ color: '#94a3b8', fontSize: '11px', marginBottom: '4px' }}>Officer</div>
                        {unit.officer_name || 'Unassigned'}
                      </div>
                      <div style={{ color: '#cbd5e1' }}>
                        <div style={{ color: '#94a3b8', fontSize: '11px', marginBottom: '4px' }}>Vehicle</div>
                        {unit.vehicle_number || 'N/A'}
                      </div>
                      <div style={{ color: '#cbd5e1' }}>
                        <div style={{ color: '#94a3b8', fontSize: '11px', marginBottom: '4px' }}>Location</div>
                        {unit.current_location || 'Unknown'}
                      </div>
                      <div style={{ color: '#cbd5e1' }}>
                        <div style={{ color: '#94a3b8', fontSize: '11px', marginBottom: '4px' }}>Last Update</div>
                        {unit.last_update ? new Date(unit.last_update).toLocaleTimeString() : 'N/A'}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `}</style>
    </div>
  );
}
