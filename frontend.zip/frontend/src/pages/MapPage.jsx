import React, { useEffect, useState } from 'react';
import { hotspot } from '../lib/api';
import Sidebar from '../components/Sidebar';
import TopBar from '../components/TopBar';

export default function MapPage() {
  const [hotspots, setHotspots] = useState([]);
  const [selectedHotspot, setSelectedHotspot] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHotspots();
  }, []);

  const loadHotspots = async () => {
    try {
      setLoading(true);
      const res = await hotspot.list();
      setHotspots(res.data);
    } catch (error) {
      console.error('Failed to load hotspots:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <Sidebar />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <TopBar onRefresh={loadHotspots} />
        <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
          <h1 style={{ marginBottom: '24px', color: '#f1f5f9' }}>Crime Hotspot Map</h1>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', height: '100%' }}>
            {/* Map visualization */}
            <div style={{
              background: 'rgba(30, 41, 59, 0.7)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(148, 163, 184, 0.2)',
              borderRadius: '16px',
              padding: '24px',
              minHeight: '500px',
              position: 'relative',
              overflow: 'hidden',
            }}>
              <div style={{
                width: '100%',
                height: '100%',
                background: 'linear-gradient(135deg, rgba(99, 102, 241, 0.1), rgba(236, 72, 153, 0.1))',
                borderRadius: '12px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                position: 'relative',
              }}>
                {loading ? (
                  <div style={{ color: '#cbd5e1' }}>Loading map data...</div>
                ) : (
                  <>
                    {/* Grid background */}
                    <svg style={{ width: '100%', height: '100%', position: 'absolute' }}>
                      <defs>
                        <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                          <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(99, 102, 241, 0.1)" strokeWidth="1"/>
                        </pattern>
                      </defs>
                      <rect width="100%" height="100%" fill="url(#grid)" />
                    </svg>

                    {/* Hotspots */}
                    {hotspots.map((spot, i) => (
                      <div
                        key={i}
                        style={{
                          position: 'absolute',
                          left: `${20 + (i * 15)}%`,
                          top: `${30 + (i * 10)}%`,
                          cursor: 'pointer',
                          zIndex: 10,
                        }}
                        onClick={() => setSelectedHotspot(spot)}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.transform = 'scale(1.3)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.transform = 'scale(1)';
                        }}
                      >
                        <div style={{
                          width: '24px',
                          height: '24px',
                          borderRadius: '50%',
                          background: '#ef4444',
                          border: '3px solid #f1f5f9',
                          boxShadow: '0 0 12px rgba(239, 68, 68, 0.6)',
                          transition: 'all 0.2s',
                        }} />
                      </div>
                    ))}
                  </>
                )}
              </div>
            </div>

            {/* Hotspots list */}
            <div style={{
              background: 'rgba(30, 41, 59, 0.7)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(148, 163, 184, 0.2)',
              borderRadius: '16px',
              padding: '24px',
              overflow: 'auto',
            }}>
              <h2 style={{ marginBottom: '16px', color: '#f1f5f9' }}>Hotspots</h2>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {loading ? (
                  <div style={{ color: '#cbd5e1' }}>Loading hotspots...</div>
                ) : hotspots.length === 0 ? (
                  <div style={{ color: '#94a3b8' }}>No hotspots found</div>
                ) : (
                  hotspots.map((spot, i) => (
                    <div
                      key={i}
                      style={{
                        padding: '16px',
                        borderRadius: '12px',
                        background: selectedHotspot?.area === spot.area ? 'rgba(99, 102, 241, 0.2)' : 'rgba(99, 102, 241, 0.1)',
                        border: `1px solid ${selectedHotspot?.area === spot.area ? '#6366f1' : 'rgba(99, 102, 241, 0.2)'}`,
                        cursor: 'pointer',
                        transition: 'all 0.2s',
                      }}
                      onClick={() => setSelectedHotspot(spot)}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.background = 'rgba(99, 102, 241, 0.15)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.background = selectedHotspot?.area === spot.area ? 'rgba(99, 102, 241, 0.2)' : 'rgba(99, 102, 241, 0.1)';
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                        <h3 style={{ margin: 0, color: '#f1f5f9', fontSize: '16px' }}>
                          {spot.area || `Hotspot ${i + 1}`}
                        </h3>
                        <span style={{
                          padding: '4px 12px',
                          borderRadius: '6px',
                          background: '#ef4444',
                          color: '#fff',
                          fontSize: '12px',
                          fontWeight: '600',
                        }}>
                          {spot.incidents || 0} incidents
                        </span>
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '12px', color: '#cbd5e1' }}>
                        <div>📍 Lat: {spot.latitude?.toFixed(4)}</div>
                        <div>🧭 Lon: {spot.longitude?.toFixed(4)}</div>
                        <div>⚠️ Risk: {spot.risk_level || 'High'}</div>
                        <div>📊 Density: {spot.density || 'High'}</div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
