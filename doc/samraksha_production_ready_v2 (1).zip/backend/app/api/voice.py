from __future__ import annotations

from fastapi import APIRouter, File, HTTPException, UploadFile
from fastapi.concurrency import run_in_threadpool

from app.services.voice import voice_service

router = APIRouter()
MAX_AUDIO_BYTES = 25 * 1024 * 1024
ALLOWED_AUDIO_TYPES = {
    "audio/wav", "audio/x-wav", "audio/mpeg", "audio/mp4", "audio/webm", "audio/ogg"
}


@router.post("/transcribe")
async def transcribe(audio: UploadFile = File(...)):
    if audio.content_type and audio.content_type not in ALLOWED_AUDIO_TYPES:
        raise HTTPException(415, "Unsupported audio format")
    payload = await audio.read(MAX_AUDIO_BYTES + 1)
    if len(payload) > MAX_AUDIO_BYTES:
        raise HTTPException(413, "Audio file exceeds the 25 MB limit")
    if not payload:
        raise HTTPException(400, "Audio file is empty")
    try:
        text = await run_in_threadpool(voice_service.transcribe, payload)
    except Exception as exc:
        raise HTTPException(503, "Voice transcription service is unavailable") from exc
    if not text or text.startswith("Transcription failed"):
        raise HTTPException(503, "Voice transcription service is unavailable")
    return {"text": text, "confidence": None}
