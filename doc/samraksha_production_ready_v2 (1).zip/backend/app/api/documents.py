from __future__ import annotations

import re
from typing import Any

import structlog
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import text

from app.api import auth
from app.api.auth import get_current_officer
from app.db.connection import get_db
from app.services.document_gen import discover_templates, generate_document, resolve_template
from app.services.translation import LANG_CODES

router = APIRouter()
logger = structlog.get_logger()


class GenerateRequest(BaseModel):
    case_id: str = Field(min_length=1, max_length=64)
    doc_type: str = Field(min_length=1, max_length=80, pattern=r"^[A-Za-z0-9_-]+$")
    language: str = Field(default="en", min_length=2, max_length=5)


def _safe_filename(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._") or "document"


def _content_disposition(filename: str) -> str:
    safe = _safe_filename(filename)
    return f'attachment; filename="{safe}"'


def _check_case_access(officer: Any, case: Any) -> None:
    if officer["role"] == "constable":
        raise HTTPException(403, "Access denied")
    if officer["role"] in ("io", "sho") and str(case["ps_id"]) != str(officer["ps_id"]):
        raise HTTPException(403, "Access denied to this case")


async def _case_context(db: Any, case_id: str, officer: Any) -> tuple[dict, dict, str]:
    case_row = (
        await db.execute(text("SELECT * FROM cases WHERE case_id = :case_id"), {"case_id": case_id})
    ).mappings().fetchone()
    if not case_row:
        raise HTTPException(404, "Case not found")
    case = dict(case_row)
    _check_case_access(officer, case)

    io_row = (
        await db.execute(
            text("SELECT name, badge_no FROM officers WHERE id = :officer_id"),
            {"officer_id": case.get("io_id")},
        )
    ).mappings().fetchone()
    ps_row = (
        await db.execute(
            text("SELECT name FROM police_stations WHERE id = :station_id"),
            {"station_id": case.get("ps_id")},
        )
    ).mappings().fetchone()
    case["ps_name"] = ps_row["name"] if ps_row else ""
    generator_officer = dict(io_row) if io_row else {
        "name": officer["name"],
        "badge_no": officer["badge_no"],
    }
    return case, generator_officer, str(case.get("fir_no") or case_id)


async def _render_document(db: Any, case_id: str, doc_type: str, language: str, officer: Any) -> tuple[bytes, str, str]:
    if language not in LANG_CODES:
        raise HTTPException(400, f"Unsupported language '{language}'")
    try:
        canonical_type, _ = resolve_template(doc_type)
    except FileNotFoundError as exc:
        raise HTTPException(400, "Document template is not available") from exc

    case, generator_officer, fir_no = await _case_context(db, case_id, officer)
    if canonical_type == "medical_letter" and not case.get("victim_injury"):
        raise HTTPException(400, "Medical letter requires victim_injury flag to be set")

    try:
        document_bytes, sha256 = await run_in_threadpool(
            generate_document,
            doc_type=canonical_type,
            case=case,
            officer=generator_officer,
            lang=language,
        )
    except FileNotFoundError as exc:
        raise HTTPException(400, "Document template is not available") from exc
    except Exception as exc:
        logger.exception("Document generation failed", doc_type=canonical_type, case_id=case_id)
        raise HTTPException(500, "Document generation failed") from exc
    return document_bytes, sha256, fir_no


@router.post("/generate")
async def generate_document_endpoint(
    request: Request,
    body: GenerateRequest,
    db=Depends(get_db),
    officer=Depends(auth.require_permission("doc_generate")),
):
    document_bytes, sha256, fir_no = await _render_document(
        db, body.case_id, body.doc_type, body.language, officer
    )
    canonical_type, _ = resolve_template(body.doc_type)

    log_result = await db.execute(
        text(
            """
            INSERT INTO doc_log (case_id, doc_type, sha256, generated_by, language)
            VALUES (:case_id, :doc_type, :sha256, :generated_by, :language)
            RETURNING id
            """
        ),
        {
            "case_id": body.case_id,
            "doc_type": canonical_type,
            "sha256": sha256,
            "generated_by": str(officer["id"]),
            "language": body.language,
        },
    )
    document_id = log_result.scalar_one()
    await db.execute(
        text(
            """
            INSERT INTO case_diary (case_id, entry_type, description, officer_id, auto_generated)
            VALUES (:case_id, 'document', :description, :officer_id, TRUE)
            """
        ),
        {
            "case_id": body.case_id,
            "description": f"{canonical_type.replace('_', ' ').title()} generated (SHA-256: {sha256[:8]}...)" ,
            "officer_id": str(officer["id"]),
        },
    )
    from app.services.audit import log_activity

    try:
        await log_activity(
            db,
            str(officer["id"]),
            "generate_document",
            f"Generated {canonical_type} for case {body.case_id}",
            request.client.host if request.client else None,
        )
    except Exception:
        logger.exception("Audit log failed on document generation")
    await db.commit()

    filename = f"{canonical_type}_{fir_no.replace('/', '_')}_{body.language}.docx"
    return Response(
        content=document_bytes,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={
            "Content-Disposition": _content_disposition(filename),
            "X-Document-ID": str(document_id),
            "X-Document-SHA256": sha256,
            "Access-Control-Expose-Headers": "Content-Disposition, X-Document-ID, X-Document-SHA256",
        },
    )


@router.get("/templates")
async def list_templates(officer=Depends(get_current_officer)):
    """Return templates discovered from the configured documents directory."""
    return discover_templates()


@router.get("")
async def list_documents(
    case_id: str,
    db=Depends(get_db),
    officer=Depends(get_current_officer),
):
    case_row = (
        await db.execute(text("SELECT case_id, ps_id FROM cases WHERE case_id = :case_id"), {"case_id": case_id})
    ).mappings().fetchone()
    if not case_row:
        raise HTTPException(404, "Case not found")
    _check_case_access(officer, case_row)

    rows = (
        await db.execute(
            text(
                """
                SELECT dl.id, dl.case_id, c.fir_no, dl.doc_type, dl.sha256,
                       dl.language, dl.generated_at, o.name AS generated_by_name
                FROM doc_log dl
                JOIN cases c ON c.case_id = dl.case_id
                LEFT JOIN officers o ON o.id = dl.generated_by
                WHERE dl.case_id = :case_id
                ORDER BY dl.generated_at DESC, dl.id DESC
                """
            ),
            {"case_id": case_id},
        )
    ).mappings().fetchall()
    return [dict(row) for row in rows]


@router.get("/{document_id}/download")
async def download_document(
    document_id: int,
    request: Request,
    db=Depends(get_db),
    officer=Depends(auth.require_permission("doc_generate")),
):
    row = (
        await db.execute(
            text(
                """
                SELECT dl.id, dl.case_id, dl.doc_type, dl.language, c.fir_no
                FROM doc_log dl
                JOIN cases c ON c.case_id = dl.case_id
                WHERE dl.id = :document_id
                """
            ),
            {"document_id": document_id},
        )
    ).mappings().fetchone()
    if not row:
        raise HTTPException(404, "Document not found")

    document_bytes, sha256, fir_no = await _render_document(
        db, str(row["case_id"]), row["doc_type"], row["language"], officer
    )
    filename = f"{row['doc_type']}_{(fir_no or row['fir_no']).replace('/', '_')}_{row['language']}.docx"
    return Response(
        content=document_bytes,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={
            "Content-Disposition": _content_disposition(filename),
            "X-Document-ID": str(document_id),
            "X-Document-SHA256": sha256,
            "Access-Control-Expose-Headers": "Content-Disposition, X-Document-ID, X-Document-SHA256",
        },
    )
