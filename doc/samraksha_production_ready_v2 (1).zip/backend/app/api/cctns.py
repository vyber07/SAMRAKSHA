from __future__ import annotations

import os
import secrets
import uuid
from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text

from app.db.connection import get_db

router = APIRouter()


class CCTNSSyncRequest(BaseModel):
    fir_no: str = Field(min_length=1, max_length=50)
    crime_type: str = Field(min_length=1, max_length=100)
    victim_name: Optional[str] = Field(default=None, max_length=200)
    accused_name: Optional[str] = Field(default=None, max_length=200)
    state: str = Field(default="Gujarat", max_length=100)
    district: str = Field(default="Ahmedabad City", max_length=100)
    lat: Optional[float] = Field(default=None, ge=-90, le=90)
    lon: Optional[float] = Field(default=None, ge=-180, le=180)


def verify_cctns_token(x_api_key: str | None = Header(default=None)):
    expected_key = os.getenv("CCTNS_API_KEY")
    if not expected_key:
        raise HTTPException(status_code=503, detail="CCTNS integration is not configured")
    if not x_api_key or not secrets.compare_digest(x_api_key, expected_key):
        raise HTTPException(status_code=401, detail="Invalid CCTNS API key")
    return True


@router.post("/sync")
async def sync_to_cctns(
    body: CCTNSSyncRequest,
    is_valid: bool = Depends(verify_cctns_token),
    db=Depends(get_db),
):
    """Persist an FIR synchronization event after authenticating the connector."""
    cctns_id = f"CCTNS-GJ-{str(uuid.uuid4())[:8].upper()}"
    try:
        existing_case = (
            await db.execute(text("SELECT case_id FROM cases WHERE fir_no = :fir_no"), {"fir_no": body.fir_no})
        ).mappings().fetchone()
        if existing_case:
            case_id = str(existing_case["case_id"])
            await db.execute(
                text(
                    """
                    INSERT INTO case_diary (case_id, entry_type, description, auto_generated)
                    VALUES (CAST(:case_id AS UUID), 'fir', :description, TRUE)
                    """
                ),
                {"case_id": case_id, "description": f"Synced FIR {body.fir_no} to CCTNS with ID {cctns_id}."},
            )
            await db.execute(
                text("UPDATE cases SET updated_at = NOW() WHERE case_id = CAST(:case_id AS UUID)"),
                {"case_id": case_id},
            )
        else:
            if body.lat is None or body.lon is None:
                raise HTTPException(status_code=400, detail="Coordinates are required for a new CCTNS case")
            case_id = str(uuid.uuid4())
            narrative = f"CCTNS synced case for FIR {body.fir_no} - {body.crime_type} ({body.district}, {body.state})"
            location = f"{body.district}, {body.state}"
            await db.execute(
                text(
                    """
                    INSERT INTO cases (
                        case_id, fir_no, crime_type, victim_name, accused_name,
                        crime_narrative, crime_date, crime_location,
                        crime_lat, crime_lon, case_status
                    ) VALUES (
                        CAST(:case_id AS UUID), :fir_no, :crime_type, :victim_name, :accused_name,
                        :narrative, NOW(), :location, :lat, :lon, 'open'
                    )
                    """
                ),
                {
                    "case_id": case_id,
                    "fir_no": body.fir_no,
                    "crime_type": body.crime_type,
                    "victim_name": body.victim_name,
                    "accused_name": body.accused_name,
                    "narrative": narrative,
                    "location": location,
                    "lat": body.lat,
                    "lon": body.lon,
                },
            )
            await db.execute(
                text(
                    """
                    INSERT INTO case_diary (case_id, entry_type, description, auto_generated)
                    VALUES (CAST(:case_id AS UUID), 'fir', :description, TRUE)
                    """
                ),
                {"case_id": case_id, "description": f"Created and synced FIR {body.fir_no} to CCTNS with ID {cctns_id}."},
            )
        await db.commit()
    except HTTPException:
        await db.rollback()
        raise
    except Exception:
        await db.rollback()
        raise HTTPException(status_code=500, detail="Failed to sync CCTNS record")

    return {
        "status": "success",
        "cctns_id": cctns_id,
        "fir_no": body.fir_no,
        "persisted_to_db": True,
        "message": f"FIR {body.fir_no} successfully synchronized and persisted.",
    }


@router.get("/search")
async def search_cctns(
    query: str = Query(min_length=1, max_length=200),
    is_valid: bool = Depends(verify_cctns_token),
    db=Depends(get_db),
):
    search_param = f"%{query}%"
    rows = (
        await db.execute(
            text(
                """
                SELECT case_id, fir_no, crime_type, case_status, victim_name,
                       accused_name, crime_location, created_at
                FROM cases
                WHERE fir_no ILIKE :query OR crime_type ILIKE :query
                   OR victim_name ILIKE :query OR accused_name ILIKE :query
                   OR crime_narrative ILIKE :query
                ORDER BY created_at DESC
                LIMIT 50
                """
            ),
            {"query": search_param},
        )
    ).mappings().fetchall()

    results = [
        {
            "cctns_id": f"CCTNS-GJ-{str(row['case_id'])[:8].upper()}",
            "fir_no": row.get("fir_no"),
            "state": "Gujarat",
            "district": "Ahmedabad City",
            "crime_type": row.get("crime_type"),
            "victim_name": row.get("victim_name"),
            "accused_name": row.get("accused_name"),
            "location": row.get("crime_location"),
            "status": row.get("case_status") or "Under Investigation",
        }
        for row in rows
    ]

    if not results and os.getenv("CCTNS_API_URL"):
        try:
            import httpx

            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(os.getenv("CCTNS_API_URL"), params={"q": query})
                if response.status_code == 200:
                    payload = response.json()
                    if isinstance(payload, list):
                        results = payload
                    elif isinstance(payload, dict) and isinstance(payload.get("results"), list):
                        results = payload["results"]
        except Exception:
            results = []

    return {"status": "success", "query": query, "results": results}
