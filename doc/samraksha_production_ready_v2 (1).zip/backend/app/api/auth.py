from __future__ import annotations

import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

import jwt as _jwt
import structlog
from fastapi import APIRouter, Cookie, Depends, HTTPException, Request, Response
from passlib.context import CryptContext
from pydantic import BaseModel, Field
from slowapi import Limiter
from slowapi.util import get_remote_address
from sqlalchemy import text

from app.core.redis import get_redis
from app.db.connection import get_db

router = APIRouter()
logger = structlog.get_logger()
limiter = Limiter(key_func=get_remote_address, enabled=os.getenv("ENVIRONMENT") != "testing")
pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")

SECRET_KEY = os.getenv("SECRET_KEY") or ""
if not SECRET_KEY:
    raise RuntimeError("SECRET_KEY environment variable must be set")
if len(SECRET_KEY) < 32:
    raise RuntimeError("SECRET_KEY must contain at least 32 characters")

ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "480"))
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "true" if os.getenv("ENVIRONMENT") == "production" else "false").lower() == "true"
COOKIE_MAX_AGE = ACCESS_TOKEN_EXPIRE_MINUTES * 60
SESSION_COOKIE = "samraksha_session"

# Valid bcrypt hash for an impossible password. It prevents a fast path for
# unknown badge numbers while avoiding any real credential in source control.
DUMMY_BCRYPT_HASH = "$2b$12$2ubAjZElIvuqCvS.MlK5juWF6mZ41zIcfa70bSc8c7JUw0FV/i.RC"


class LoginRequest(BaseModel):
    badge_no: str = Field(min_length=1, max_length=20)
    password: str = Field(min_length=1, max_length=256)


def create_access_token(officer_id: str, role: str, ps_id: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": officer_id,
        "role": role,
        "ps_id": ps_id,
        "exp": now + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES),
        "iat": now,
        "jti": str(uuid.uuid4()),
    }
    return _jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


async def _is_revoked(jti: str | None) -> bool:
    if not jti:
        return False
    try:
        redis = get_redis()
        try:
            return bool(await redis.get(f"blacklist:{jti}"))
        finally:
            await redis.aclose()
    except Exception:
        # A valid JWT remains usable if the optional revocation store is down.
        # Log the degraded state so operators can alert on it.
        logger.warning("Token revocation store unavailable")
        return False


async def get_current_officer(
    request: Request,
    samraksha_session: str | None = Cookie(default=None),
    db=Depends(get_db),
):
    token = samraksha_session
    if not token:
        authorization = request.headers.get("Authorization", "")
        if authorization.startswith("Bearer "):
            token = authorization[7:].strip()
    if not token:
        raise HTTPException(401, "Not authenticated")

    try:
        payload = _jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        officer_id_raw = payload.get("sub")
        if not officer_id_raw or await _is_revoked(payload.get("jti")):
            raise HTTPException(401, "Invalid or revoked token")
        officer_id = uuid.UUID(str(officer_id_raw))
    except HTTPException:
        raise
    except (_jwt.ExpiredSignatureError, _jwt.InvalidTokenError, ValueError):
        raise HTTPException(401, "Invalid or expired token")

    row = (
        await db.execute(
            text(
                """
                SELECT id, badge_no, name, role, ps_id, is_active
                FROM officers
                WHERE id = :officer_id
                """
            ),
            {"officer_id": officer_id},
        )
    ).mappings().fetchone()
    if not row or not row["is_active"]:
        raise HTTPException(401, "Officer account inactive")

    officer: dict[str, Any] = dict(row)
    overrides = (
        await db.execute(
            text(
                """
                SELECT permission_key, granted
                FROM officer_permission_overrides
                WHERE officer_id = :officer_id
                  AND (expires_at IS NULL OR expires_at > NOW())
                """
            ),
            {"officer_id": officer_id},
        )
    ).mappings().fetchall()
    officer["permissions"] = {item["permission_key"]: item["granted"] for item in overrides}
    return officer


def require_permission(permission_key: str):
    async def check_permission(officer=Depends(get_current_officer)):
        overrides = officer.get("permissions", {})
        if permission_key in overrides:
            if overrides[permission_key]:
                return officer
            raise HTTPException(403, "Permission denied by override")

        role_permissions = {
            "constable": {"patrol_view"},
            "io": {"case_create", "case_view_own_ps", "case_edit", "patrol_view", "doc_generate"},
            "sho": {"case_view_all", "case_edit", "doc_generate", "patrol_dispatch", "patrol_view", "cctv_view", "analytics_view"},
            "dcp": {"case_view_all", "analytics_view", "patrol_view", "cctv_view", "doc_generate"},
            "admin": {"admin_permissions", "analytics_view", "case_create", "case_view_all", "case_view_own_ps", "case_edit", "doc_generate", "patrol_dispatch", "patrol_view", "cctv_view"},
        }
        if permission_key not in role_permissions.get(officer["role"], set()):
            raise HTTPException(403, "Insufficient permissions")
        return officer

    return check_permission


@router.post("/login")
@limiter.limit("5/minute")
async def login(request: Request, body: LoginRequest, db=Depends(get_db)):
    row = (
        await db.execute(
            text(
                """
                SELECT id, badge_no, name, role, ps_id, password_hash, is_active
                FROM officers
                WHERE badge_no = :badge_no
                """
            ),
            {"badge_no": body.badge_no.strip()},
        )
    ).mappings().fetchone()

    stored_hash = str(row["password_hash"] if row else DUMMY_BCRYPT_HASH)
    try:
        valid_password = pwd_ctx.verify(body.password, stored_hash)
    except Exception:
        valid_password = False
    if not row or not valid_password:
        logger.warning("Failed login", badge=body.badge_no, ip=request.client.host if request.client else None)
        raise HTTPException(401, "Invalid credentials")
    if not row["is_active"]:
        raise HTTPException(401, "Account deactivated")

    officer_id = uuid.UUID(str(row["id"]))
    await db.execute(
        text("UPDATE officers SET last_login = NOW() WHERE id = :officer_id"),
        {"officer_id": officer_id},
    )
    token = create_access_token(str(row["id"]), row["role"], str(row["ps_id"]))

    from app.services.audit import log_activity

    try:
        await log_activity(
            db,
            officer_id,
            "login",
            f"Officer {row['badge_no']} logged in successfully.",
            request.client.host if request.client else None,
        )
    except Exception:
        logger.exception("Audit logging failed on login")
    await db.commit()

    response = Response(
        content=__import__("json").dumps(
            {
                "token_type": "bearer",
                "officer": {
                    "id": str(row["id"]),
                    "badge_no": row["badge_no"],
                    "name": row["name"],
                    "role": row["role"],
                    "ps_id": str(row["ps_id"]),
                },
            }
        ),
        media_type="application/json",
    )
    response.set_cookie(
        key=SESSION_COOKIE,
        value=token,
        httponly=True,
        secure=COOKIE_SECURE,
        samesite="strict",
        max_age=COOKIE_MAX_AGE,
        path="/",
    )
    response.headers["Cache-Control"] = "no-store"
    return response


@router.post("/logout")
async def logout(
    request: Request,
    response: Response,
    officer=Depends(get_current_officer),
    db=Depends(get_db),
):
    token = request.cookies.get(SESSION_COOKIE)
    if not token:
        authorization = request.headers.get("Authorization", "")
        if authorization.startswith("Bearer "):
            token = authorization[7:].strip()

    payload = None
    if token:
        try:
            payload = _jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM], options={"verify_exp": False})
        except _jwt.InvalidTokenError:
            payload = None

    if payload and payload.get("jti"):
        ttl = max(1, int(payload.get("exp", 0) - datetime.now(timezone.utc).timestamp()))
        try:
            redis = get_redis()
            try:
                await redis.set(f"blacklist:{payload['jti']}", "true", ex=ttl)
            finally:
                await redis.aclose()
        except Exception:
            logger.warning("Logout token revocation failed")

    response.delete_cookie(SESSION_COOKIE, path="/")
    from app.services.audit import log_activity

    try:
        await log_activity(
            db,
            officer["id"],
            "logout",
            f"Officer {officer['badge_no']} logged out.",
            request.client.host if request.client else None,
        )
        await db.commit()
    except Exception:
        logger.exception("Logout audit logging failed")
    return {"message": "Logged out"}


@router.get("/me")
async def get_me(officer=Depends(get_current_officer)):
    return {
        "officer": {
            "id": str(officer["id"]),
            "badge_no": officer["badge_no"],
            "name": officer["name"],
            "role": officer["role"],
            "ps_id": str(officer["ps_id"]),
        }
    }
