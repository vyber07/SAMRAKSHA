from __future__ import annotations

import os
import time
from collections import defaultdict

import jwt as _jwt
import structlog
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

SECRET_KEY = os.getenv("SECRET_KEY") or ""
ALGORITHM = "HS256"
SESSION_COOKIE = "samraksha_session"
logger = structlog.get_logger()
router = APIRouter()

class DashboardManager:
    def __init__(self):
        self.connections: dict[str, list[WebSocket]] = defaultdict(list)

    async def connect(self, websocket: WebSocket, officer_id: str):
        await websocket.accept()
        if websocket not in self.connections[officer_id]:
            self.connections[officer_id].append(websocket)
        await websocket.send_json({"type": "INIT", "payload": {"message": "Connected"}, "ts": int(time.time() * 1000)})

    def disconnect(self, websocket: WebSocket, officer_id: str):
        sockets = self.connections.get(officer_id, [])
        if websocket in sockets:
            sockets.remove(websocket)
        if not sockets:
            self.connections.pop(officer_id, None)

    async def broadcast(self, event: dict):
        payload = {**event, "ts": event.get("ts", int(time.time() * 1000))}
        for officer_id, sockets in list(self.connections.items()):
            for websocket in list(sockets):
                try:
                    await websocket.send_json(payload)
                except Exception:
                    self.disconnect(websocket, officer_id)


manager = DashboardManager()


def _officer_id_from_token(token: str | None) -> str | None:
    if not token or not SECRET_KEY:
        return None
    try:
        payload = _jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return str(payload["sub"]) if payload.get("sub") else None
    except (_jwt.ExpiredSignatureError, _jwt.InvalidTokenError, KeyError, TypeError):
        return None

@router.websocket("/dashboard")
async def websocket_endpoint(websocket: WebSocket):
    officer_id = _officer_id_from_token(websocket.cookies.get(SESSION_COOKIE))
    if not officer_id:
        # Backward-compatible handshake for older clients, without placing the
        # token in the URL. New clients authenticate through the HttpOnly cookie.
        await websocket.accept()
        try:
            token = await websocket.receive_text()
        except Exception:
            await websocket.close(code=1008, reason="Missing authentication")
            return
        officer_id = _officer_id_from_token(token.removeprefix("Bearer ").strip())
    if not officer_id:
        await websocket.close(code=1008, reason="Invalid or expired authentication")
        return

    await manager.connect(websocket, officer_id)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket, officer_id)
    except Exception:
        manager.disconnect(websocket, officer_id)


