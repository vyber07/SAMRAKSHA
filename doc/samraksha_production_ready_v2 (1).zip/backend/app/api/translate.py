"""Authenticated translation endpoint backed by the configured translation service."""

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from app.api.auth import get_current_officer
from app.services.translation import LANG_CODES, TranslationUnavailable, translator_service

router = APIRouter()


class TranslateRequest(BaseModel):
    text: str = Field(min_length=1, max_length=20000)
    target_lang: str = Field(min_length=2, max_length=5)
    source_lang: str = Field(default="en", min_length=2, max_length=5)


class TranslateResponse(BaseModel):
    original: str
    translated: str
    source_lang: str
    target_lang: str
    model: str = "IndicTrans2"


@router.post("/", response_model=TranslateResponse)
async def translate_text(body: TranslateRequest, officer=Depends(get_current_officer)):
    source_lang = body.source_lang.strip().lower()
    target_lang = body.target_lang.strip().lower()
    if source_lang not in LANG_CODES:
        raise HTTPException(400, f"Unsupported source language '{source_lang}'")
    if target_lang not in LANG_CODES:
        raise HTTPException(400, f"Unsupported target language '{target_lang}'")
    try:
        translated = await translator_service.translate(
            body.text,
            target_lang=target_lang,
            source_lang=source_lang,
        )
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except TranslationUnavailable as exc:
        raise HTTPException(503, "Translation service is not available") from exc

    return TranslateResponse(
        original=body.text,
        translated=translated,
        source_lang=source_lang,
        target_lang=target_lang,
    )


@router.get("/languages")
async def list_languages(officer=Depends(get_current_officer)):
    return {
        "languages": [
            {"code": code, "flores_code": flores}
            for code, flores in LANG_CODES.items()
        ]
    }
