"""IndicTrans2 translation service with an optional local LLM fallback."""

from __future__ import annotations

import asyncio
import os
from typing import Any

import structlog
try:
    import torch
except ImportError:  # Optional until a non-English translation is requested.
    torch = None

logger = structlog.get_logger()

LANG_CODES = {
    "hi": "hin_Deva",
    "mr": "mar_Deva",
    "ta": "tam_Taml",
    "te": "tel_Telu",
    "kn": "kan_Knda",
    "gu": "guj_Gujr",
    "pa": "pan_Guru",
    "bn": "ben_Beng",
    "or": "ory_Orya",
    "ml": "mal_Mlym",
    "as": "asm_Beng",
    "ur": "urd_Arab",
    "en": "eng_Latn",
}
MAX_TRANSLATION_CHARS = int(os.getenv("MAX_TRANSLATION_CHARS", "20000"))

_models: dict[str, Any] = {}
_processors: dict[str, Any] = {}


class TranslationUnavailable(RuntimeError):
    """Raised when no configured translation engine can satisfy a request."""


def validate_language(code: str) -> str:
    if code not in LANG_CODES:
        raise ValueError(f"Unsupported language '{code}'")
    return code


def _get_model_and_processor(direction: str):
    if direction in _models:
        return _models[direction], _processors[direction]

    model_map = {
        "en-indic": "ai4bharat/indictrans2-en-indic-1B",
        "indic-en": "ai4bharat/indictrans2-indic-en-1B",
    }
    model_name = model_map.get(direction)
    if not model_name:
        raise TranslationUnavailable(f"Unsupported translation direction '{direction}'")

    if torch is None:
        _models[direction] = None
        _processors[direction] = None
        return None, None
    try:
        logger.info("Loading IndicTrans2 model", model=model_name)
        from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
        from IndicTransToolkit import IndicProcessor

        processor = IndicProcessor(inference=True)
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
        device = "cuda" if torch.cuda.is_available() else "cpu"
        model = model.to(device)
        model.eval()
        _models[direction] = (model, tokenizer, device)
        _processors[direction] = processor
        return _models[direction], processor
    except Exception as exc:
        logger.exception("IndicTrans2 load failed", direction=direction)
        _models[direction] = None
        _processors[direction] = None
        return None, None


class Translator:
    """Translate bounded text through IndicTrans2 or a configured local LLM."""

    async def translate(self, text: str, target_lang: str, source_lang: str = "en") -> str:
        text = self._validate_text(text)
        validate_language(target_lang)
        validate_language(source_lang)
        if not text or target_lang == source_lang:
            return text
        return await asyncio.to_thread(self.translate_sync, text, target_lang, source_lang)

    def translate_sync(self, text: str, target_lang: str, source_lang: str = "en") -> str:
        text = self._validate_text(text)
        validate_language(target_lang)
        validate_language(source_lang)
        if not text or target_lang == source_lang:
            return text
        return self._translate_blocking(text, target_lang, source_lang)

    def _translate_blocking(self, text: str, target_lang: str, source_lang: str) -> str:
        if source_lang == "en" and target_lang != "en":
            direction = "en-indic"
            source_flores, target_flores = LANG_CODES["en"], LANG_CODES[target_lang]
        elif source_lang != "en" and target_lang == "en":
            direction = "indic-en"
            source_flores, target_flores = LANG_CODES[source_lang], LANG_CODES["en"]
        else:
            raise TranslationUnavailable("Indic-to-Indic translation is not configured")

        model_tuple, processor = _get_model_and_processor(direction)
        if model_tuple is not None and processor is not None:
            model, tokenizer, device = model_tuple
            try:
                batch = processor.preprocess_batch([text], src_lang=source_flores, tgt_lang=target_flores)
                inputs = tokenizer(batch, truncation=True, padding="longest", return_tensors="pt").to(device)
                with torch.no_grad():
                    outputs = model.generate(**inputs, num_beams=5, num_return_sequences=1, max_length=512)
                decoded = tokenizer.batch_decode(outputs, skip_special_tokens=True)
                result = processor.postprocess_batch(decoded, lang=target_flores)
                if result and result[0].strip():
                    return result[0].strip()
            except Exception:
                logger.exception("IndicTrans2 inference failed", direction=direction)

        return self._translate_with_llamacpp(text, source_lang, target_lang)

    def _translate_with_llamacpp(self, text: str, source_lang: str, target_lang: str) -> str:
        import httpx

        base_url = os.getenv("LLAMACPP_URL")
        if not base_url:
            raise TranslationUnavailable(
                "IndicTrans2 is unavailable and LLAMACPP_URL is not configured"
            )
        prompt = (
            f"Translate the following text from {source_lang} to {target_lang}. "
            "Return only the translated text, with no explanation, markdown, or quotes.\n\n"
            f"{text}"
        )
        try:
            with httpx.Client(timeout=30.0) as client:
                response = client.post(
                    f"{base_url.rstrip('/')}/v1/chat/completions",
                    json={"messages": [{"role": "user", "content": prompt}], "stream": False},
                )
                response.raise_for_status()
                translated = response.json().get("choices", [{}])[0].get("message", {}).get("content", "")
        except Exception as exc:
            raise TranslationUnavailable("Configured translation fallback is unavailable") from exc
        if not isinstance(translated, str) or not translated.strip():
            raise TranslationUnavailable("Translation engine returned no text")
        return translated.strip()

    @staticmethod
    def _validate_text(text: str) -> str:
        if not isinstance(text, str):
            raise ValueError("text must be a string")
        if len(text) > MAX_TRANSLATION_CHARS:
            raise ValueError(f"text exceeds the {MAX_TRANSLATION_CHARS}-character limit")
        return text.strip()


translator_service = Translator()
