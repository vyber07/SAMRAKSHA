from __future__ import annotations

import os
import tempfile

import structlog

logger = structlog.get_logger()
_whisper_model = None


def load_whisper_model():
    global _whisper_model
    if _whisper_model is None:
        try:
            import whisper

            logger.info("Loading Whisper-small model")
            _whisper_model = whisper.load_model("small")
        except Exception:
            logger.exception("Failed to load Whisper model")
            _whisper_model = False
    return _whisper_model


class VoiceService:
    def transcribe(self, audio_bytes: bytes) -> str:
        model = load_whisper_model()
        if not model:
            raise RuntimeError("Whisper model is not available")

        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".webm") as temporary_file:
                temporary_file.write(audio_bytes)
                tmp_path = temporary_file.name
            result = model.transcribe(tmp_path)
            text = str(result.get("text", "")).strip()
            if not text:
                raise RuntimeError("Whisper returned no transcript")
            return text
        finally:
            if tmp_path:
                try:
                    os.unlink(tmp_path)
                except FileNotFoundError:
                    pass


voice_service = VoiceService()
