"""Production document generation service.

Templates are discovered from the configured documents directory. Adding a new
DOCX file therefore makes it available through the API without changing a
Python allow-list. The document log remains the source of truth for generated
artifacts; the binary is regenerated on demand from the persisted case data.
"""

from __future__ import annotations

import hashlib
import io
import os
import re
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

from docxtpl import DocxTemplate

from app.services.translation import translator_service


_BACKEND_ROOT = Path(__file__).resolve().parents[2]
_DEFAULT_TEMPLATE_DIR = _BACKEND_ROOT / "templates" / "documents"
_TEMPLATE_ID_ALIASES = {
    "face_id": "face_identification",
    "panchanama": "accused_panchanama",
    "fir": "chargesheet_bns2024",
    "case_diary": "accused_panchanama",
    "arrest_memo": "accused_panchanama",
    "seizure_list": "seizure_receipt",
    "search_warrant": "court_custody_bnss",
    "bail_objection": "remand_request_bnss",
}


def template_directory() -> Path:
    configured = os.getenv("DOCUMENT_TEMPLATE_DIR")
    directory = Path(configured).expanduser() if configured else _DEFAULT_TEMPLATE_DIR
    return directory.resolve()


def _slug(value: str) -> str:
    value = re.sub(r"(?:_bns2024|_bnss)$", "", value, flags=re.IGNORECASE)
    value = re.sub(r"[^a-zA-Z0-9]+", "_", value).strip("_").lower()
    return value


def discover_templates() -> list[dict[str, str]]:
    """Return all valid DOCX templates in stable order.

    The API exposes the normalized file stem as the template id. A template
    can be added by placing a DOCX file in the configured directory; no code
    change is required.
    """
    directory = template_directory()
    if not directory.is_dir():
        return []

    templates: list[dict[str, str]] = []
    seen: set[str] = set()
    for path in sorted(directory.glob("*.docx"), key=lambda item: item.name.lower()):
        template_id = _slug(path.stem)
        if not template_id or template_id in seen:
            continue
        seen.add(template_id)
        templates.append(
            {
                "id": template_id,
                "name": template_id.replace("_", " ").title(),
                "filename": path.name,
            }
        )
    return templates


def resolve_template(doc_type: str) -> tuple[str, Path]:
    """Resolve a client template id, including legacy aliases, to a DOCX path."""
    requested = _slug(doc_type)
    directory = template_directory()
    candidates = [requested]
    alias = _TEMPLATE_ID_ALIASES.get(doc_type) or _TEMPLATE_ID_ALIASES.get(requested)
    if alias:
        candidates.append(alias)

    discovered = {item["id"]: item for item in discover_templates()}
    for candidate in candidates:
        if candidate in discovered:
            return candidate, directory / discovered[candidate]["filename"]

    # Preserve exact filename matching for ids such as chargesheet_bns2024.
    for path in directory.glob("*.docx"):
        if path.stem.lower() in candidates:
            return _slug(path.stem), path

    raise FileNotFoundError(f"No document template registered for '{doc_type}'")


def generate_document(
    doc_type: str,
    case: dict[str, Any],
    officer: dict[str, Any],
    lang: str = "en",
) -> tuple[bytes, str]:
    """Render a document template and return its bytes and SHA-256 digest."""
    _, template_path = resolve_template(doc_type)
    sections = case.get("bns_sections") or []

    context = {
        "FIR_NO": case.get("fir_no", ""),
        "DATE": today_formatted(),
        "PS_NAME": translate(case.get("ps_name", ""), lang),
        "IO_NAME": officer.get("name", ""),
        "IO_BADGE": officer.get("badge_no", ""),
        "VICTIM_NAME": translate(case.get("victim_name", ""), lang),
        "VICTIM_ADDRESS": translate(case.get("victim_address", ""), lang),
        "VICTIM_AGE": str(case.get("victim_age") or ""),
        "VICTIM_PHONE": case.get("victim_phone", ""),
        "ACCUSED_NAME": translate(case.get("accused_name", ""), lang),
        "ACCUSED_ADDRESS": translate(case.get("accused_address", ""), lang),
        "ACCUSED_AGE": str(case.get("accused_age") or ""),
        "CRIME_TYPE": translate(case.get("crime_type", ""), lang),
        "CRIME_DATE": format_date(case.get("crime_date")),
        "CRIME_LOCATION": translate(case.get("crime_location", ""), lang),
        "CRIME_NARRATIVE": translate(case.get("crime_narrative", ""), lang),
        "BNS_SECTIONS": ", ".join(str(item) for item in sections),
        "BNSS_SECTIONS": ", ".join(str(item) for item in (case.get("bnss_sections") or [])),
        "BSA_SECTIONS": ", ".join(str(item) for item in (case.get("bsa_sections") or [])),
        "IPC_CROSSREF": ", ".join(str(item) for item in (case.get("ipc_crossref") or [])),
        "LANDMARK_CASES": format_landmark_cases(case.get("landmark_cases") or []),
        "EVIDENCE_LIST": format_evidence(case.get("evidence_items") or [], lang),
        "WITNESS_LIST": format_witnesses(case.get("witnesses") or [], lang),
        "ARREST_DATE": format_date(case.get("arrest_date")),
        "ARREST_LOCATION": translate(case.get("arrest_location", ""), lang),
    }

    document = DocxTemplate(str(template_path))
    document.render(context)
    buffer = io.BytesIO()
    document.save(buffer)
    raw = buffer.getvalue()
    return raw, hashlib.sha256(raw).hexdigest()


def today_formatted() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def format_date(value: Any) -> str:
    if not value:
        return ""
    if isinstance(value, (datetime, date)):
        return value.strftime("%Y-%m-%d")
    return str(value)[:10]


def translate(text: str, lang: str) -> str:
    if not text or lang == "en":
        return text or ""
    return translator_service.translate_sync(text, lang)


def format_landmark_cases(cases: list[Any]) -> str:
    return ", ".join(item if isinstance(item, str) else str(item) for item in cases)


def format_evidence(evidence: list[Any], lang: str) -> str:
    text = ", ".join(item if isinstance(item, str) else str(item) for item in evidence)
    return translate(text, lang)


def format_witnesses(witnesses: list[Any], lang: str) -> str:
    text = ", ".join(item if isinstance(item, str) else str(item) for item in witnesses)
    return translate(text, lang)
