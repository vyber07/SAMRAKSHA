-- Allow new DOCX templates to be added without changing a Python allow-list.
-- The application validates the template against the configured documents directory.
ALTER TABLE doc_log DROP CONSTRAINT IF EXISTS doc_log_doc_type_check;
ALTER TABLE doc_log ALTER COLUMN doc_type TYPE VARCHAR(80);
