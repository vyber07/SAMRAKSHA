from __future__ import annotations

import os
from contextlib import asynccontextmanager

import structlog
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from app.api import admin, analytics, assistant, auth, cases, cctns, cctv, documents, incidents, legal, patrol, translate, voice, websocket, hotspot
from app.db.connection import close_db, init_db

logger = structlog.get_logger()
ENVIRONMENT = os.getenv("ENVIRONMENT", "development").lower()


def _csv_env(name: str, default: list[str]) -> list[str]:
    raw = os.getenv(name)
    if raw is None:
        return default
    return [item.strip() for item in raw.split(",") if item.strip()]


CORS_ORIGINS = _csv_env(
    "CORS_ORIGINS",
    ["http://localhost:3000", "http://localhost", "http://127.0.0.1:3000"],
)
TRUSTED_HOSTS = _csv_env("TRUSTED_HOSTS", ["localhost", "127.0.0.1", "backend"])
if ENVIRONMENT == "production" and ("*" in CORS_ORIGINS or "*" in TRUSTED_HOSTS):
    raise RuntimeError("Wildcard CORS or trusted hosts are forbidden in production")


@asynccontextmanager
async def lifespan(app: FastAPI):
    secret = os.getenv("SECRET_KEY", "")
    if ENVIRONMENT == "production" and len(secret) < 32:
        raise RuntimeError("SECRET_KEY must be at least 32 characters in production")
    await init_db()
    logger.info("Database connected")
    yield
    await close_db()
    logger.info("Database disconnected")


limiter = Limiter(key_func=get_remote_address)
app = FastAPI(
    title="SAMRAKSHA API",
    version="1.0.0",
    description="Unified Predictive Policing & Advanced Case Intelligence Platform",
    docs_url="/api/docs" if ENVIRONMENT != "production" else None,
    redoc_url=None,
    lifespan=lifespan,
)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Accept", "Authorization", "Content-Type", "X-CSRF-Token"],
)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=TRUSTED_HOSTS)

for prefix in ["/api/v1"]:
    app.include_router(auth.router, prefix=f"{prefix}/auth", tags=["Auth"])
    app.include_router(cases.router, prefix=f"{prefix}/cases", tags=["Cases"])
    app.include_router(incidents.router, prefix=f"{prefix}/incident", tags=["Incidents"])
    app.include_router(patrol.router, prefix=f"{prefix}/patrol", tags=["Patrol"])
    app.include_router(hotspot.router, prefix=f"{prefix}/map", tags=["Map"])
    app.include_router(cctv.router, prefix=f"{prefix}/cctv", tags=["CCTV"])
    app.include_router(assistant.router, prefix=f"{prefix}/assistant", tags=["Assistant"])
    app.include_router(legal.router, prefix=f"{prefix}/legal", tags=["Legal"])
    app.include_router(websocket.router, prefix=f"{prefix}/ws", tags=["WebSocket"])
    app.include_router(admin.router, prefix=f"{prefix}/admin", tags=["Admin"])
    app.include_router(analytics.router, prefix=f"{prefix}/analytics", tags=["Analytics"])
    app.include_router(translate.router, prefix=f"{prefix}/translate", tags=["Translation"])
    app.include_router(cctns.router, prefix=f"{prefix}/cctns", tags=["CCTNS"])
    app.include_router(documents.router, prefix=f"{prefix}/docs", tags=["Documents"])
    app.include_router(voice.router, prefix=f"{prefix}/voice", tags=["Voice"])


@app.get("/")
async def root():
    return {"message": "Welcome to SAMRAKSHA API", "health": "/health"}


@app.get("/health")
@app.get("/api/health")
async def health():
    db_ok = False
    redis_ok = False
    try:
        from app.db.connection import engine
        from sqlalchemy import text

        async with engine.begin() as conn:
            await conn.execute(text("SELECT 1"))
        db_ok = True
    except Exception:
        logger.warning("Health check database probe failed")
    try:
        from app.core.redis import redis_client

        await redis_client.ping()
        redis_ok = True
    except Exception:
        logger.warning("Health check Redis probe failed")

    return {
        "status": "ok" if db_ok and redis_ok else "degraded",
        "service": "SAMRAKSHA",
        "version": "1.0.0",
        "db": db_ok,
        "redis": redis_ok,
    }
